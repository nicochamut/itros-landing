import React from "react";
import styled from "styled-components";
import { motion } from "motion/react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { Benefits } from "./components/Benefits";
import { Solutions } from "./components/Solutions";
import { Testimonials } from "./components/Testimonials";
import { Checkout } from "./components/Checkout";
import { PaymentSuccess } from "./components/PaymentSuccess";
import { PaymentFailure } from "./components/PaymentFailure";
import { PaymentPending } from "./components/PaymentPending";
import { CTA } from "./components/CTA";
import { Footer } from "./components/Footer";

const AppContainer = styled(motion.div)`
  min-height: 100vh;
  background-color: #0f0f0f;
  position: relative;
`;

const BackgroundGradient = styled(motion.div)`
  position: fixed;
  inset: 0;
  background: linear-gradient(135deg, #0f0f0f 0%, #1a1a1a 50%, #000000 100%);
  opacity: 0.8;
`;

const GeometricBackground = styled.div`
  position: fixed;
  inset: 0;
  opacity: 0.05;
`;

const GeometricCircle1 = styled(motion.div)`
  position: absolute;
  top: 25%;
  right: 25%;
  width: 24rem;
  height: 24rem;
  border: 1px solid rgba(231, 76, 60, 0.2);
  border-radius: 50%;
`;

const GeometricCircle2 = styled(motion.div)`
  position: absolute;
  bottom: 33.333333%;
  left: 20%;
  width: 20rem;
  height: 20rem;
  border: 1px solid rgba(230, 126, 34, 0.2);
  border-radius: 50%;
`;

const GeometricCircle3 = styled(motion.div)`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 37.5rem;
  height: 37.5rem;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 50%;
`;

const ContentContainer = styled(motion.div)`
  position: relative;
  z-index: 10;
`;

// Animación de entrada principal
const pageVariants = {
  initial: {
    opacity: 0,
    y: 20
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: [0.25, 0.1, 0.25, 1]
    }
  }
};

// Animación del gradiente de fondo
const backgroundVariants = {
  initial: {
    opacity: 0
  },
  animate: {
    opacity: 0.8,
    transition: {
      duration: 1.2,
      ease: "easeOut"
    }
  }
};

// Animaciones para los círculos geométricos
const circleVariants = {
  initial: {
    scale: 0,
    opacity: 0
  },
  animate: {
    scale: 1,
    opacity: 0.05,
    transition: {
      duration: 1.5,
      ease: "easeOut"
    }
  }
};

// Animación del contenido principal
const contentVariants = {
  initial: {
    opacity: 0
  },
  animate: {
    opacity: 1,
    transition: {
      duration: 0.6,
      delay: 0.3,
      staggerChildren: 0.1
    }
  }
};

export default function App() {
  // Simple routing based on pathname
  const pathname = window.location.pathname;

  // Payment result pages
  if (pathname === '/payment-success') {
    return <PaymentSuccess />;
  }
  
  if (pathname === '/payment-failure') {
    return <PaymentFailure />;
  }
  
  if (pathname === '/payment-pending') {
    return <PaymentPending />;
  }

  return (
    <AppContainer
      variants={pageVariants}
      initial="initial"
      animate="animate"
    >
      <BackgroundGradient
        variants={backgroundVariants}
        initial="initial"
        animate="animate"
      />
      
      <GeometricBackground>
        <GeometricCircle1
          variants={circleVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.5 }}
        />
        <GeometricCircle2
          variants={circleVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.7 }}
        />
        <GeometricCircle3
          variants={circleVariants}
          initial="initial"
          animate="animate"
          transition={{ delay: 0.9 }}
        />
      </GeometricBackground>
      
      <ContentContainer
        variants={contentVariants}
        initial="initial"
        animate="animate"
      >
        <Header />
        <main>
          <Hero />
          <Benefits />
          <Solutions />
          <Testimonials />
          <CTA />
        </main>
        <Footer />
      </ContentContainer>
    </AppContainer>
  );
}