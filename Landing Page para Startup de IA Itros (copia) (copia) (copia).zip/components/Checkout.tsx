import { useState } from 'react';
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import { 
  Check, 
  Crown, 
  Zap, 
  Building2, 
  CreditCard, 
  Loader2,
  Star,
  Shield,
  Sparkles
} from "lucide-react";
import { projectId, publicAnonKey } from '../utils/supabase/info';

const plans = [
  {
    id: 'starter',
    name: 'Starter',
    price: 29.99,
    currency: 'USD',
    icon: Zap,
    popular: false,
    color: 'from-electric-blue to-cyan-400',
    features: [
      'Hasta 1,000 consultas de IA al mes',
      'Análisis básico de datos',
      'Soporte por email',
      'Dashboard básico',
      'API access limitado'
    ]
  },
  {
    id: 'professional',
    name: 'Professional',
    price: 99.99,
    currency: 'USD',
    icon: Crown,
    popular: true,
    color: 'from-purple-500 to-violet-400',
    features: [
      'Hasta 10,000 consultas de IA al mes',
      'Análisis predictivo avanzado',
      'Soporte prioritario 24/7',
      'Dashboard completo con insights',
      'API access completo',
      'Integraciones personalizadas',
      'Reportes avanzados'
    ]
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 299.99,
    currency: 'USD',
    icon: Building2,
    popular: false,
    color: 'from-orange-500 to-yellow-400',
    features: [
      'Consultas ilimitadas',
      'IA personalizada para tu negocio',
      'Soporte dedicado',
      'Dashboard empresarial',
      'API sin límites',
      'Integraciones ilimitadas',
      'Análisis en tiempo real',
      'Consultoría personalizada',
      'SLA garantizado'
    ]
  }
];

export function Checkout() {
  const [selectedPlan, setSelectedPlan] = useState<string>('professional');
  const [userEmail, setUserEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handlePayment = async () => {
    if (!userEmail) {
      setError('Por favor ingresa tu email');
      return;
    }

    if (!selectedPlan) {
      setError('Por favor selecciona un plan');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-f21ceeec/create-payment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          plan: selectedPlan,
          userEmail: userEmail,
          userId: `user_${Date.now()}` // In real app, this would come from auth
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Error al crear el pago');
      }

      const { initPoint, sandboxInitPoint } = await response.json();
      
      // Redirect to Mercado Pago checkout
      // In development, use sandbox. In production, use initPoint
      const checkoutUrl = sandboxInitPoint || initPoint;
      window.open(checkoutUrl, '_blank');

    } catch (err) {
      console.error('Payment error:', err);
      setError(err instanceof Error ? err.message : 'Error al procesar el pago');
    } finally {
      setIsLoading(false);
    }
  };

  const selectedPlanData = plans.find(plan => plan.id === selectedPlan);

  return (
    <section id="checkout-section" className="py-24 px-4 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-96 h-96 bg-electric-blue/20 rounded-full blur-3xl opacity-40"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-purple-500/15 rounded-full blur-3xl opacity-50"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-xl px-4 py-2 rounded-full border border-white/20 shadow-lg">
            <Sparkles className="w-4 h-4 text-electric-blue" />
            <span className="text-sm text-electric-blue font-medium">
              Planes y Precios
            </span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-light tracking-tight text-white">
            Elige el plan{" "}
            <span className="bg-gradient-to-r from-electric-blue to-purple-400 bg-clip-text text-transparent">
              perfecto
            </span>{" "}
            para tu negocio
          </h2>
          <p className="text-xl text-white/70 max-w-3xl mx-auto">
            Comienza con nuestro plan gratuito y escala según tus necesidades. 
            Todos los planes incluyen soporte completo y actualizaciones automáticas.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 items-start">
          {/* Plans Selection */}
          <div className="space-y-6">
            <h3 className="text-2xl font-medium text-white mb-6">Selecciona tu plan</h3>
            
            <div className="space-y-4">
              {plans.map((plan) => {
                const PlanIcon = plan.icon;
                const isSelected = selectedPlan === plan.id;
                
                return (
                  <Card
                    key={plan.id}
                    className={`cursor-pointer transition-all duration-500 border-2 ${
                      isSelected 
                        ? 'border-electric-blue shadow-2xl shadow-electric-blue/30 bg-white/15' 
                        : 'border-white/20 hover:border-white/40 bg-white/5 hover:bg-white/10'
                    } backdrop-blur-xl group hover:scale-[1.02]`}
                    onClick={() => setSelectedPlan(plan.id)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 bg-gradient-to-br ${plan.color} rounded-xl flex items-center justify-center shadow-lg`}>
                            <PlanIcon className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium text-white">{plan.name}</h4>
                              {plan.popular && (
                                <Badge className="bg-electric-blue text-white text-xs">
                                  <Star className="w-3 h-3 mr-1" />
                                  Popular
                                </Badge>
                              )}
                            </div>
                            <p className="text-2xl font-light text-white">
                              ${plan.price}
                              <span className="text-sm text-white/70 ml-1">/{plan.currency} mes</span>
                            </p>
                          </div>
                        </div>
                        <div className={`w-5 h-5 rounded-full border-2 ${
                          isSelected 
                            ? 'border-electric-blue bg-electric-blue' 
                            : 'border-white/40'
                        } flex items-center justify-center`}>
                          {isSelected && <Check className="w-3 h-3 text-white" />}
                        </div>
                      </div>
                      
                      <div className="mt-4 space-y-2">
                        {plan.features.slice(0, 3).map((feature, index) => (
                          <div key={index} className="flex items-center gap-2 text-sm text-white/80">
                            <Check className="w-4 h-4 text-electric-blue" />
                            {feature}
                          </div>
                        ))}
                        {plan.features.length > 3 && (
                          <div className="text-sm text-white/60">
                            +{plan.features.length - 3} características más
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Checkout Form */}
          <div className="space-y-6">
            <Card className="border border-white/20 shadow-2xl bg-white/5 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-electric-blue" />
                  Resumen del pedido
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {selectedPlanData && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-white/10 rounded-xl backdrop-blur-sm border border-white/20">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 bg-gradient-to-br ${selectedPlanData.color} rounded-lg flex items-center justify-center`}>
                          <selectedPlanData.icon className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-medium text-white">Plan {selectedPlanData.name}</div>
                          <div className="text-sm text-white/70">Facturación mensual</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-light text-white">${selectedPlanData.price}</div>
                        <div className="text-sm text-white/70">{selectedPlanData.currency}</div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <Label htmlFor="email" className="text-white">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="tu@empresa.com"
                        value={userEmail}
                        onChange={(e) => setUserEmail(e.target.value)}
                        className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-electric-blue backdrop-blur-sm"
                      />
                    </div>

                    {error && (
                      <div className="p-3 bg-red-500/20 border border-red-500/30 rounded-lg text-red-300 text-sm backdrop-blur-sm">
                        {error}
                      </div>
                    )}

                    <Button
                      onClick={handlePayment}
                      disabled={isLoading || !userEmail}
                      className="w-full bg-gradient-to-r from-electric-blue to-cyan-400 hover:from-cyan-400 hover:to-electric-blue text-white shadow-2xl shadow-electric-blue/30 hover:shadow-electric-blue/60 transition-all duration-500 hover:scale-105 backdrop-blur-sm border border-white/10 py-6"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Procesando...
                        </>
                      ) : (
                        <>
                          <Shield className="w-4 h-4 mr-2" />
                          Pagar con Mercado Pago
                        </>
                      )}
                    </Button>

                    <div className="text-xs text-white/60 text-center">
                      Pago seguro procesado por Mercado Pago. 
                      Puedes cancelar en cualquier momento.
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Trust Indicators */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-xl p-4 text-center">
                <Shield className="w-6 h-6 text-green-400 mx-auto mb-2" />
                <div className="text-sm text-white font-medium">Pago Seguro</div>
                <div className="text-xs text-white/70">SSL 256-bit</div>
              </div>
              <div className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-xl p-4 text-center">
                <Star className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
                <div className="text-sm text-white font-medium">Garantía</div>
                <div className="text-xs text-white/70">30 días</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}