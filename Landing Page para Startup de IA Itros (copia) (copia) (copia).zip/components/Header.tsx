import { Button } from "./ui/button";
import { Brain, Menu, X } from "lucide-react";
import { useState } from "react";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-corporate-darker/90 backdrop-blur-xl border-b border-white/5">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center gap-3 group">
            <div className="w-10 h-10 bg-corporate-red rounded-sm flex items-center justify-center transition-all duration-300 group-hover:bg-corporate-orange">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-light text-white tracking-tight font-[Instrument_Sans]">ITROS</span>
          </div>
          
          {/* Navigation - Desktop */}
          <nav className="hidden lg:flex items-center gap-12">
            <button 
              onClick={() => {
                const section = document.getElementById('solutions-section');
                if (section) section.scrollIntoView({ behavior: 'smooth' });
              }}
              className="text-corporate-text-muted hover:text-white transition-all duration-300 text-overline relative group"
            >
              Servicios
              <span className="absolute inset-x-0 -bottom-1 h-px bg-corporate-red scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></span>
            </button>
            <button 
              onClick={() => {
                const section = document.getElementById('benefits-section');
                if (section) section.scrollIntoView({ behavior: 'smooth' });
              }}
              className="text-corporate-text-muted hover:text-white transition-all duration-300 text-overline relative group"
            >
              Soluciones
              <span className="absolute inset-x-0 -bottom-1 h-px bg-corporate-red scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></span>
            </button>
            <button 
              onClick={() => {
                const section = document.getElementById('testimonials-section');
                if (section) section.scrollIntoView({ behavior: 'smooth' });
              }}
              className="text-corporate-text-muted hover:text-white transition-all duration-300 text-overline relative group"
            >
              Testimonios
              <span className="absolute inset-x-0 -bottom-1 h-px bg-corporate-red scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></span>
            </button>
            <a href="#" className="text-corporate-text-muted hover:text-white transition-all duration-300 text-overline relative group">
              Nosotros
              <span className="absolute inset-x-0 -bottom-1 h-px bg-corporate-red scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></span>
            </a>
          </nav>
          
          {/* CTA - Desktop */}
          <div className="hidden lg:flex items-center gap-6">
            <Button 
              variant="ghost" 
              className="text-corporate-text-muted hover:text-white hover:bg-transparent text-overline transition-all duration-300"
            >
              Iniciar Sesión
            </Button>
            <Button 
              onClick={() => {
                const section = document.getElementById('cta-section');
                if (section) section.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-corporate-red hover:bg-corporate-orange text-white px-8 py-3 text-overline transition-all duration-300 border-0 rounded-sm"
            >
              Comenzar
            </Button>
          </div>
          
          {/* Mobile menu button */}
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden text-white hover:bg-transparent p-0"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </Button>
        </div>
        
        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-white/10 py-8 space-y-6 bg-corporate-darker">
            <button 
              onClick={() => {
                const section = document.getElementById('solutions-section');
                if (section) section.scrollIntoView({ behavior: 'smooth' });
                setMobileMenuOpen(false);
              }}
              className="block text-corporate-text-muted hover:text-white transition-all duration-300 text-overline"
            >
              Servicios
            </button>
            <button 
              onClick={() => {
                const section = document.getElementById('benefits-section');
                if (section) section.scrollIntoView({ behavior: 'smooth' });
                setMobileMenuOpen(false);
              }}
              className="block text-corporate-text-muted hover:text-white transition-all duration-300 text-overline"
            >
              Soluciones
            </button>
            <button 
              onClick={() => {
                const section = document.getElementById('testimonials-section');
                if (section) section.scrollIntoView({ behavior: 'smooth' });
                setMobileMenuOpen(false);
              }}
              className="block text-corporate-text-muted hover:text-white transition-all duration-300 text-overline"
            >
              Testimonios
            </button>
            <a href="#" className="block text-corporate-text-muted hover:text-white transition-all duration-300 text-overline">
              Nosotros
            </a>
            <div className="flex flex-col gap-4 pt-6 border-t border-white/10">
              <Button variant="ghost" className="w-full justify-start text-corporate-text-muted hover:text-white hover:bg-transparent text-overline">
                Iniciar Sesión
              </Button>
              <Button 
                onClick={() => {
                  const section = document.getElementById('cta-section');
                  if (section) section.scrollIntoView({ behavior: 'smooth' });
                  setMobileMenuOpen(false);
                }}
                className="bg-corporate-red hover:bg-corporate-orange text-white w-full text-overline transition-all duration-300 border-0 rounded-sm py-3"
              >
                Comenzar
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}