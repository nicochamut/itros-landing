import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { 
  Check, 
  ArrowRight,
  Zap,
  Crown,
  Building2
} from "lucide-react";

const products = [
  {
    id: 'starter',
    name: 'INICIAL',
    price: 29.99,
    currency: 'USD',
    description: 'Herramientas esenciales de IA para empresas en crecimiento',
    features: [
      '1,000 consultas de IA mensuales',
      'Análisis básico de datos',
      'Soporte por email',
      'Panel estándar',
      'Acceso limitado a API'
    ],
    highlight: 'Perfecto para startups'
  },
  {
    id: 'professional',
    name: 'PROFESIONAL',
    price: 99.99,
    currency: 'USD',
    description: 'Soluciones avanzadas para operaciones escalables',
    popular: true,
    features: [
      '10,000 consultas de IA mensuales',
      'Análisis predictivo avanzado',
      'Soporte prioritario 24/7',
      'Suite completa de paneles',
      'Acceso completo a API',
      'Integraciones personalizadas',
      'Reportes avanzados'
    ],
    highlight: 'Opción más popular'
  },
  {
    id: 'enterprise',
    name: 'EMPRESARIAL',
    price: 299.99,
    currency: 'USD',
    description: 'Transformación completa de IA para grandes organizaciones',
    features: [
      'Consultas de IA ilimitadas',
      'Modelos de IA personalizados',
      'Equipo de soporte dedicado',
      'Panel empresarial',
      'Acceso ilimitado a API',
      'Todas las integraciones incluidas',
      'Análisis en tiempo real',
      'Consultoría personalizada',
      'Garantía de SLA'
    ],
    highlight: 'Máxima capacidad'
  }
];

export function ProductShowcase() {
  const scrollToCheckout = () => {
    const checkoutSection = document.getElementById('checkout-section');
    if (checkoutSection) {
      checkoutSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-32 px-6 lg:px-8 relative">
      {/* Section header */}
      <div className="max-w-6xl mx-auto mb-24">
        <div className="grid lg:grid-cols-2 gap-16 items-end">
          <div className="space-y-8">
            <div className="space-y-4">
              <h6 className="text-xs uppercase tracking-widest text-corporate-text-muted font-light">
                Planes de Precios
              </h6>
              <h2 className="text-4xl lg:text-6xl font-light text-white leading-tight">
                ELIGE TU
                <br />
                <span className="text-corporate-red">SOLUCIÓN</span>
              </h2>
            </div>
            <p className="text-lg text-corporate-text-muted leading-relaxed font-light max-w-lg">
              Precios transparentes diseñados para escalar con tu negocio. 
              Cada plan incluye nuestras capacidades centrales de IA con diferentes niveles de acceso y soporte.
            </p>
          </div>

          {/* Trust indicators */}
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-px bg-corporate-red"></div>
              <span className="text-sm uppercase tracking-wider text-corporate-text-muted font-light">
                Confianza de Líderes de la Industria
              </span>
            </div>
            <div className="grid grid-cols-2 gap-4 text-center">
              <div className="p-4 border border-white/10 bg-white/5">
                <div className="text-2xl font-light text-white">500+</div>
                <div className="text-xs uppercase tracking-wider text-corporate-text-muted">Empresas</div>
              </div>
              <div className="p-4 border border-white/10 bg-white/5">
                <div className="text-2xl font-light text-white">99.9%</div>
                <div className="text-xs uppercase tracking-wider text-corporate-text-muted">Disponibilidad</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <Card
              key={product.id}
              className={`relative border bg-white/5 backdrop-blur-sm transition-all duration-500 group hover:-translate-y-2 ${
                product.popular 
                  ? 'border-corporate-red bg-corporate-red/5' 
                  : 'border-white/10 hover:border-white/20'
              }`}
            >
              {product.popular && (
                <div className="absolute -top-4 left-6 bg-corporate-red text-white px-4 py-1 text-xs uppercase tracking-widest font-light">
                  Más Popular
                </div>
              )}

              <CardContent className="p-8 space-y-8">
                {/* Header */}
                <div className="space-y-6">
                  <div className="space-y-2">
                    <h3 className="text-xl font-light text-white tracking-widest">
                      {product.name}
                    </h3>
                    <p className="text-sm text-corporate-text-muted font-light leading-relaxed">
                      {product.description}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-light text-white">${product.price}</span>
                      <span className="text-sm text-corporate-text-muted uppercase tracking-wider">/{product.currency} mes</span>
                    </div>
                    <div className="text-xs uppercase tracking-wider text-corporate-red font-light">
                      {product.highlight}
                    </div>
                  </div>
                </div>

                {/* Features */}
                <div className="space-y-4">
                  <h4 className="text-xs uppercase tracking-widest text-corporate-text-muted font-light border-b border-white/10 pb-2">
                    Qué está Incluido
                  </h4>
                  <div className="space-y-3">
                    {product.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-start gap-3 text-sm text-corporate-text-muted group-hover:text-white/80 transition-colors duration-300">
                        <Check className="w-4 h-4 text-corporate-red flex-shrink-0 mt-0.5" />
                        <span className="font-light">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* CTA Button */}
                <Button 
                  onClick={scrollToCheckout}
                  className={`w-full py-4 text-sm uppercase tracking-widest font-light transition-all duration-300 border-0 rounded-sm ${
                    product.popular
                      ? 'bg-corporate-red hover:bg-corporate-orange text-white'
                      : 'bg-white/10 hover:bg-white/20 text-white border border-white/20 hover:border-white/40'
                  }`}
                >
                  <span>Elegir {product.name}</span>
                  <ArrowRight className="ml-3 w-4 h-4" />
                </Button>
              </CardContent>

              {/* Bottom accent line */}
              <div className={`absolute bottom-0 left-0 w-0 h-px group-hover:w-full transition-all duration-700 ${
                product.popular ? 'bg-corporate-red' : 'bg-white/30'
              }`}></div>
            </Card>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-24 text-center space-y-8">
          <div className="max-w-3xl mx-auto space-y-6">
            <h3 className="text-3xl font-light text-white">
              ¿Listo para Transformar tu Negocio?
            </h3>
            <p className="text-lg text-corporate-text-muted font-light leading-relaxed">
              Únete a más de 500 empresas que confían en Itros para potenciar su transformación de IA. 
              Comienza tu jornada hoy con una garantía de satisfacción de 30 días.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button 
              onClick={scrollToCheckout}
              size="lg"
              className="bg-corporate-red hover:bg-corporate-orange text-white px-12 py-4 text-sm uppercase tracking-widest font-light transition-all duration-300 border-0 rounded-sm"
            >
              Comenzar Ahora
              <ArrowRight className="ml-3 w-4 h-4" />
            </Button>
            
            <Button 
              variant="ghost" 
              size="lg"
              className="text-white hover:text-corporate-red border border-white/20 hover:border-corporate-red px-12 py-4 text-sm uppercase tracking-widest font-light transition-all duration-300 bg-transparent hover:bg-transparent rounded-sm"
              onClick={() => {
                window.open('mailto:ventas@itros.ai?subject=Consulta%20Empresarial', '_blank');
              }}
            >
              Hablar con Ventas
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}