import { Brain, Mail, Phone, MapPin, ArrowRight } from "lucide-react";
import { Button } from "./ui/button";

export function Footer() {
  return (
    <footer className="bg-corporate-dark border-t border-white/10">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Main footer content */}
        <div className="py-16 grid lg:grid-cols-4 gap-12">
          {/* Company info */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-corporate-red rounded-sm flex items-center justify-center">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-light text-white tracking-tight">Itros</span>
            </div>
            <p className="text-corporate-text-muted font-light leading-relaxed">
              Transformando empresas a través de automatización inteligente e insights basados en datos.
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-corporate-red" />
                <span className="text-sm text-corporate-text-muted font-light">hola@itros.ai</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-corporate-red" />
                <span className="text-sm text-corporate-text-muted font-light">+34 91 123 4567</span>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-corporate-red" />
                <span className="text-sm text-corporate-text-muted font-light">Madrid, España</span>
              </div>
            </div>
          </div>

          {/* Services */}
          <div className="space-y-6">
            <h6 className="text-xs uppercase tracking-widest text-white font-light">Servicios</h6>
            <div className="space-y-3">
              {[
                "Consultoría de Estrategia IA",
                "Desarrollo de Modelos Personalizados", 
                "Automatización de Procesos",
                "Análisis de Datos",
                "Aprendizaje Automático"
              ].map((service, index) => (
                <button key={index} className="block text-corporate-text-muted hover:text-white transition-colors duration-300 text-sm font-light text-left">
                  {service}
                </button>
              ))}
            </div>
          </div>

          {/* Company */}
          <div className="space-y-6">
            <h6 className="text-xs uppercase tracking-widest text-white font-light">Empresa</h6>
            <div className="space-y-3">
              {[
                "Sobre Nosotros",
                "Carreras",
                "Blog",
                "Casos de Estudio",
                "Contacto"
              ].map((item, index) => (
                <button key={index} className="block text-corporate-text-muted hover:text-white transition-colors duration-300 text-sm font-light text-left">
                  {item}
                </button>
              ))}
            </div>
          </div>

          {/* Newsletter */}
          <div className="space-y-6">
            <h6 className="text-xs uppercase tracking-widest text-white font-light">Mantente Informado</h6>
            <p className="text-sm text-corporate-text-muted font-light leading-relaxed">
              Obtén las últimas perspectivas sobre tendencias de IA y desarrollos de la industria.
            </p>
            <div className="space-y-3">
              <div className="flex">
                <input
                  type="email"
                  placeholder="Ingresa tu email"
                  className="flex-1 bg-white/5 border border-white/10 px-4 py-3 text-sm text-white placeholder-corporate-text-muted focus:outline-none focus:border-corporate-red transition-colors duration-300 rounded-l-sm"
                />
                <Button className="bg-corporate-red hover:bg-corporate-orange text-white px-4 border-0 rounded-l-none rounded-r-sm">
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-xs text-corporate-text-muted font-light">
                Sin spam, cancela en cualquier momento.
              </p>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="py-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-corporate-text-muted font-light">
            © 2024 Itros. Todos los derechos reservados.
          </p>
          <div className="flex gap-8">
            <button className="text-sm text-corporate-text-muted hover:text-white transition-colors duration-300 font-light">
              Política de Privacidad
            </button>
            <button className="text-sm text-corporate-text-muted hover:text-white transition-colors duration-300 font-light">
              Términos de Servicio
            </button>
            <button className="text-sm text-corporate-text-muted hover:text-white transition-colors duration-300 font-light">
              Política de Cookies
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}