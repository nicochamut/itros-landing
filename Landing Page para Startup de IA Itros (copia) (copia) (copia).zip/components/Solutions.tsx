import { Brain, Target, Headphones, ArrowRight } from "lucide-react";

const solutions = [
  {
    title: "ESTRATEGIA",
    subtitle: "Descubre más",
    description: "Desarrollamos estrategias integrales de IA adaptadas a tus objetivos empresariales, asegurando integración perfecta con flujos de trabajo existentes y máximo ROI.",
    icon: Target
  },
  {
    title: "CREATIVIDAD",
    subtitle: "Descubre más", 
    description: "Nuestras soluciones creativas de IA mejoran la generación de contenido, automatización de diseño y experiencias de usuario personalizadas en todos los puntos de contacto digitales.",
    icon: Brain
  },
  {
    title: "SOPORTE",
    subtitle: "Descubre más",
    description: "Soporte dedicado 24/7 asegura que tus sistemas de IA operen sin fallas, con monitoreo proactivo y resolución instantánea de problemas.",
    icon: Headphones
  }
];

export function Solutions() {
  return (
    <section id="solutions-section" className="py-32 px-6 lg:px-8 relative overflow-hidden">
      {/* Background geometric elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 border border-corporate-red/20 rounded-full"></div>
        <div className="absolute bottom-1/3 right-1/4 w-80 h-80 border border-corporate-orange/20 rounded-full"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] border border-white/5 rounded-full"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="mb-24 space-y-8">
          <div className="space-y-4">
            <h6 className="text-xs uppercase tracking-widest text-corporate-text-muted font-light">
              Nuestros Servicios
            </h6>
            <h2 className="text-5xl lg:text-7xl font-light text-white leading-tight">
              CÓMO
              <br />
              <span className="text-corporate-red">TRABAJAMOS</span>
            </h2>
          </div>
        </div>

        {/* Circular Solutions Layout */}
        <div className="relative">
          {/* Center connecting lines */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-px h-32 bg-gradient-to-b from-transparent via-white/20 to-transparent"></div>
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-32 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>
          </div>

          {/* Solutions Grid */}
          <div className="grid lg:grid-cols-3 gap-16 lg:gap-24">
            {solutions.map((solution, index) => {
              const SolutionIcon = solution.icon;
              return (
                <div key={index} className="text-center space-y-8 group">
                  {/* Circular container */}
                  <div className="relative">
                    <div className="w-64 h-64 mx-auto border border-white/20 rounded-full bg-white/5 backdrop-blur-sm flex items-center justify-center transition-all duration-500 group-hover:border-corporate-red/40 group-hover:bg-corporate-red/5">
                      <div className="text-center space-y-4">
                        <SolutionIcon className="w-8 h-8 text-corporate-red mx-auto" />
                        <div className="space-y-2">
                          <h3 className="text-xl font-light text-white tracking-widest">
                            {solution.title}
                          </h3>
                          <p className="text-xs uppercase tracking-wider text-corporate-text-muted font-light">
                            {solution.subtitle}
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    {/* Connecting dots */}
                    <div className="absolute top-1/2 -right-8 w-2 h-2 bg-corporate-red/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 lg:block hidden"></div>
                    <div className="absolute top-1/2 -left-8 w-2 h-2 bg-corporate-red/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 lg:block hidden"></div>
                  </div>

                  {/* Description */}
                  <div className="max-w-sm mx-auto space-y-4">
                    <p className="text-corporate-text-muted font-light leading-relaxed">
                      {solution.description}
                    </p>
                    <button className="inline-flex items-center gap-2 text-corporate-red hover:text-corporate-orange transition-colors duration-300 text-sm uppercase tracking-wider font-light group">
                      Saber Más
                      <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform duration-300" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom section */}
        <div className="mt-32 pt-16 border-t border-white/10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-6">
              <h3 className="text-3xl lg:text-4xl font-light text-white leading-tight">
                PORTAFOLIO
              </h3>
              <p className="text-corporate-text-muted font-light leading-relaxed">
                Nuestro estudio ayuda a los clientes a volverse más eficientes, ágiles y resilientes, mientras entregamos experiencias excepcionales al cliente y construimos soluciones con impacto duradero.
              </p>
              <button className="inline-flex items-center gap-3 text-corporate-red hover:text-corporate-orange transition-colors duration-300 text-sm uppercase tracking-wider font-light group">
                Ver Nuestro Trabajo
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
              </button>
            </div>
            
            <div className="space-y-8">
              {[
                { number: "01", title: "Estrategia de IA", desc: "Marcos de inteligencia personalizados" },
                { number: "02", title: "Implementación", desc: "Integración perfecta de sistemas" },
                { number: "03", title: "Optimización", desc: "Mejora continua del rendimiento" },
                { number: "04", title: "Soporte", desc: "Asociación continua para el éxito" }
              ].map((item, index) => (
                <div key={index} className="flex items-start gap-6 group cursor-pointer">
                  <span className="text-2xl font-light text-corporate-red group-hover:text-corporate-orange transition-colors duration-300">
                    {item.number}
                  </span>
                  <div className="space-y-1">
                    <h4 className="font-light text-white group-hover:text-corporate-red transition-colors duration-300">
                      {item.title}
                    </h4>
                    <p className="text-sm text-corporate-text-muted font-light">
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}