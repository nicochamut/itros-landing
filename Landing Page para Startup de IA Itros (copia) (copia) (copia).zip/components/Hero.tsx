import { Button } from "./ui/button";
import { ArrowRight, Play } from "lucide-react";

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center px-6 lg:px-8">
      {/* Background geometric elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 right-1/6 w-2 h-2 bg-corporate-red rounded-full animate-pulse"></div>
        <div className="absolute bottom-1/3 left-1/4 w-1 h-1 bg-corporate-orange rounded-full animate-pulse" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-1/2 right-1/3 w-1.5 h-1.5 bg-white rounded-full animate-pulse" style={{animationDelay: '2s'}}></div>
      </div>

      <div className="max-w-6xl mx-auto text-center relative z-10">
        <div className="space-y-16">
          {/* Overline */}
          <div className="inline-flex items-center gap-3 px-4 py-2 border border-white/10 rounded-sm bg-white/5 backdrop-blur-sm">
            <div className="w-2 h-2 bg-corporate-red rounded-full animate-pulse"></div>
            <span className="text-overline text-corporate-text-muted">
              Soluciones de Inteligencia Artificial
            </span>
          </div>

          {/* Main headline */}
          <div className="space-y-12">
            <h1 className="text-hero text-white tracking-extra-tight">
              NUESTRO
              <br />
              <span className="text-corporate-red">ENFOQUE</span>
              <br />
              AL TRABAJO
            </h1>
            
            <p className="text-body-large text-corporate-text-muted max-w-4xl mx-auto">
              Transformamos empresas a través de automatización inteligente e insights basados en datos, 
              entregando soluciones que escalan con tu ambición y redefinen tu futuro digital.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-8 justify-center items-center">
            <Button 
              size="lg" 
              className="bg-corporate-red hover:bg-corporate-orange text-white px-12 py-4 text-overline transition-all duration-300 border-0 rounded-sm group"
              onClick={() => {
                const solutionsSection = document.getElementById('solutions-section');
                if (solutionsSection) {
                  solutionsSection.scrollIntoView({ behavior: 'smooth' });
                }
              }}
            >
              <span>Explorar Soluciones</span>
              <ArrowRight className="ml-3 w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
            </Button>
            
            <Button 
              variant="ghost" 
              size="lg" 
              className="text-white hover:text-corporate-red border border-white/20 hover:border-corporate-red px-12 py-4 text-overline transition-all duration-300 bg-transparent hover:bg-transparent rounded-sm group"
              onClick={() => {
                const solutionsSection = document.getElementById('solutions-section');
                if (solutionsSection) {
                  solutionsSection.scrollIntoView({ behavior: 'smooth' });
                }
              }}
            >
              <Play className="mr-3 w-4 h-4 group-hover:scale-110 transition-transform duration-300" />
              <span>Ver Demo</span>
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-20 border-t border-white/10">
            {[
              { number: "500+", label: "Empresas Confían en Nosotros" },
              { number: "99.9%", label: "Garantía de Disponibilidad" },
              { number: "24/7", label: "Soporte Disponible" },
              { number: "50+", label: "Países Atendidos" }
            ].map((stat, index) => (
              <div key={index} className="text-center space-y-3">
                <div className="text-4xl md:text-5xl font-light text-white tracking-super-tight">{stat.number}</div>
                <div className="text-overline text-corporate-text-muted">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div className="w-px h-16 bg-gradient-to-b from-transparent via-white/30 to-transparent"></div>
        <div className="w-2 h-2 bg-white/50 rounded-full mx-auto mt-2 animate-bounce"></div>
      </div>
    </section>
  );
}