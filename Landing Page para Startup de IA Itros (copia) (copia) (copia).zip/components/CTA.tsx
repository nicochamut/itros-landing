import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { ArrowRight, CheckCircle } from "lucide-react";
import { useState } from "react";

export function CTA() {
  const [email, setEmail] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Email submitted:", email);
    setEmail("");
  };

  return (
    <section id="cta-section" className="py-32 px-6 lg:px-8 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-corporate-red/30 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-corporate-orange/20 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-5xl mx-auto relative z-10">
        <div className="relative overflow-hidden bg-white/5 backdrop-blur-sm border border-white/10 p-16 lg:p-20 group hover:bg-white/10 transition-all duration-500">
          
          <div className="relative z-10 text-center space-y-12">
            <div className="space-y-8">
              <div className="space-y-6">
                <h6 className="text-overline text-corporate-text-muted">
                  Comienza Hoy
                </h6>
                <h2 className="text-white tracking-extra-tight">
                  ¿LISTO PARA
                  <br />
                  <span className="text-corporate-red">TRANSFORMAR</span>
                  <br />
                  TU NEGOCIO?
                </h2>
              </div>
              
              <p className="text-body-large text-corporate-text-muted max-w-3xl mx-auto">
                Comienza tu viaje hacia la inteligencia artificial hoy mismo. 
                Únete a más de 500 empresas que ya confían en Itros para impulsar su crecimiento 
                y revolucionar sus procesos empresariales.
              </p>
            </div>
            
            <form onSubmit={handleSubmit} className="max-w-lg mx-auto space-y-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <Input
                  type="email"
                  placeholder="tu@empresa.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="flex-1 bg-white/5 border border-white/20 text-white placeholder:text-corporate-text-muted focus:bg-white/10 focus:border-corporate-red hover:bg-white/10 transition-all duration-300 rounded-sm h-12"
                />
                <Button 
                  type="submit"
                  size="lg"
                  className="bg-corporate-red hover:bg-corporate-orange text-white px-8 py-3 text-overline transition-all duration-300 border-0 rounded-sm group h-12"
                >
                  <span>Comenzar Gratis</span>
                  <ArrowRight className="ml-3 w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
                </Button>
              </div>
              <p className="text-body-small text-corporate-text-muted">
                Sin tarjeta de crédito requerida • Prueba gratuita de 14 días
              </p>
            </form>
            
            <div className="grid sm:grid-cols-3 gap-8 pt-12 border-t border-white/10">
              {[
                "Implementación en 24 horas",
                "Soporte 24/7 incluido", 
                "Garantía de satisfacción"
              ].map((feature, index) => (
                <div key={index} className="flex items-center justify-center gap-3 text-corporate-text-muted group hover:text-white transition-colors duration-300">
                  <div className="w-4 h-4 bg-corporate-red rounded-full flex items-center justify-center group-hover:bg-corporate-orange transition-colors duration-300">
                    <CheckCircle className="w-2.5 h-2.5 text-white" />
                  </div>
                  <span className="text-body-small">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}