import { Brain, Zap, Shield, TrendingUp, Users, Clock } from "lucide-react";
import { Card, CardContent } from "./ui/card";

const benefits = [
  {
    icon: Brain,
    title: "IA Inteligente",
    description: "Algoritmos de machine learning que aprenden y se adaptan continuamente a tus necesidades empresariales específicas.",
    color: "from-corporate-red to-corporate-orange"
  },
  {
    icon: Zap,
    title: "Procesamiento Rápido",
    description: "Análisis de datos en tiempo real con velocidades de procesamiento hasta 10x más rápidas que soluciones tradicionales.",
    color: "from-corporate-orange to-yellow-500"
  },
  {
    icon: Shield,
    title: "Seguridad Avanzada",
    description: "Protección de datos de nivel empresarial con encriptación end-to-end y cumplimiento total de GDPR y estándares internacionales.",
    color: "from-green-500 to-emerald-500"
  },
  {
    icon: TrendingUp,
    title: "Análisis Predictivo",
    description: "Predicciones precisas basadas en datos históricos que te ayudan a tomar decisiones estratégicas informadas.",
    color: "from-purple-500 to-violet-500"
  },
  {
    icon: Users,
    title: "Colaboración",
    description: "Herramientas diseñadas para equipos distribuidos, facilitando la colaboración y el intercambio de insights en tiempo real.",
    color: "from-pink-500 to-rose-500"
  },
  {
    icon: Clock,
    title: "Disponibilidad 24/7",
    description: "Sistemas siempre activos con monitoreo continuo y soporte técnico especializado disponible las 24 horas del día.",
    color: "from-blue-500 to-indigo-500"
  }
];

export function Benefits() {
  return (
    <section id="benefits-section" className="py-32 px-6 lg:px-8 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-1/4 w-64 h-64 bg-corporate-red/30 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-corporate-orange/20 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center space-y-8 mb-24">
          <div className="space-y-6">
            <h6 className="text-overline text-corporate-text-muted">
              Beneficios
            </h6>
            <h2 className="text-white tracking-extra-tight">
              POR QUÉ
              <br />
              <span className="text-corporate-red">ELEGIR ITROS</span>
            </h2>
          </div>
          <p className="text-body-large text-corporate-text-muted max-w-3xl mx-auto">
            Descubre cómo nuestras soluciones de inteligencia artificial pueden 
            transformar tu empresa y llevarte al siguiente nivel de eficiencia, productividad e innovación.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <Card 
                key={index} 
                className="border border-white/10 bg-white/5 backdrop-blur-sm hover:bg-white/10 transition-all duration-500 group hover:-translate-y-2 overflow-hidden relative"
              >
                {/* Animated background gradient */}
                <div className={`absolute inset-0 bg-gradient-to-br ${benefit.color} opacity-0 group-hover:opacity-5 transition-opacity duration-500`}></div>
                
                <CardContent className="p-8 space-y-6 relative z-10">
                  <div className={`w-12 h-12 bg-gradient-to-br ${benefit.color} rounded-sm flex items-center justify-center group-hover:scale-110 transition-all duration-500 shadow-lg shadow-black/20`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-xl font-medium text-white tracking-tight group-hover:text-corporate-red transition-colors duration-300">
                      {benefit.title}
                    </h3>
                    <p className="text-body-small text-corporate-text-muted leading-relaxed group-hover:text-white/90 transition-colors duration-300">
                      {benefit.description}
                    </p>
                  </div>
                  
                  {/* Hover effect line */}
                  <div className={`h-px w-0 bg-gradient-to-r ${benefit.color} group-hover:w-full transition-all duration-500`}></div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}