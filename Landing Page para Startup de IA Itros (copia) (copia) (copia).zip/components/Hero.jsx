import React from "react";
import styled, { keyframes } from "styled-components";
import { motion } from "motion/react";
import { ArrowRight, Play } from "lucide-react";

const pulse = keyframes`
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
`;

const bounce = keyframes`
  0%, 20%, 53%, 80%, 100% {
    transform: translate3d(0, 0, 0);
  }
  40%, 43% {
    transform: translate3d(0, -30px, 0);
  }
  70% {
    transform: translate3d(0, -15px, 0);
  }
  90% {
    transform: translate3d(0, -4px, 0);
  }
`;

const HeroSection = styled(motion.section)`
  position: relative;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 1.5rem;

  @media (min-width: 1024px) {
    padding: 0 2rem;
  }
`;

const BackgroundElements = styled.div`
  position: absolute;
  inset: 0;
  opacity: 0.1;
`;

const PulsingDot1 = styled.div`
  position: absolute;
  top: 25%;
  right: 16.666667%;
  width: 0.5rem;
  height: 0.5rem;
  background-color: #e74c3c;
  border-radius: 50%;
  animation: ${pulse} 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
`;

const PulsingDot2 = styled.div`
  position: absolute;
  bottom: 33.333333%;
  left: 25%;
  width: 0.25rem;
  height: 0.25rem;
  background-color: #e67e22;
  border-radius: 50%;
  animation: ${pulse} 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
  animation-delay: 1s;
`;

const PulsingDot3 = styled.div`
  position: absolute;
  top: 50%;
  right: 33.333333%;
  width: 0.375rem;
  height: 0.375rem;
  background-color: white;
  border-radius: 50%;
  animation: ${pulse} 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
  animation-delay: 2s;
`;

const HeroContent = styled(motion.div)`
  max-width: 72rem;
  margin: 0 auto;
  text-align: center;
  position: relative;
  z-index: 10;
`;

const ContentContainer = styled(motion.div)`
  display: flex;
  flex-direction: column;
  gap: 4rem;
`;

const Overline = styled(motion.div)`
  display: inline-flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.5rem 1rem;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 0.125rem;
  background-color: rgba(255, 255, 255, 0.05);
  backdrop-filter: blur(8px);
`;

const OverlineDot = styled.div`
  width: 0.5rem;
  height: 0.5rem;
  background-color: #e74c3c;
  border-radius: 50%;
  animation: ${pulse} 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
`;

const OverlineText = styled.span`
  font-size: 0.75rem;
  font-weight: 600;
  line-height: 1.2;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  color: #8a8a8a;
`;

const HeadlineContainer = styled(motion.div)`
  display: flex;
  flex-direction: column;
  gap: 3rem;
`;

const MainHeadline = styled(motion.h1)`
  font-size: clamp(3rem, 8vw, 6rem);
  font-weight: 200;
  line-height: 0.95;
  letter-spacing: -0.04em;
  color: white;
  text-wrap: balance;
`;

const HighlightText = styled.span`
  color: #e74c3c;
`;

const SubHeadline = styled(motion.p)`
  font-size: clamp(1.125rem, 2vw, 1.25rem);
  font-weight: 300;
  line-height: 1.6;
  letter-spacing: -0.015em;
  color: #8a8a8a;
  max-width: 64rem;
  margin: 0 auto;
  text-wrap: pretty;
`;

const CTAContainer = styled(motion.div)`
  display: flex;
  flex-direction: column;
  gap: 2rem;
  justify-content: center;
  align-items: center;

  @media (min-width: 640px) {
    flex-direction: row;
  }
`;

const PrimaryButton = styled.button`
  background-color: #e74c3c;
  color: white;
  padding: 1rem 3rem;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  transition: all 0.3s ease;
  border: none;
  border-radius: 0.125rem;
  cursor: pointer;
  display: flex;
  align-items: center;

  &:hover {
    background-color: #e67e22;
  }

  .arrow-icon {
    margin-left: 0.75rem;
    transition: transform 0.3s ease;
  }

  &:hover .arrow-icon {
    transform: translateX(0.25rem);
  }
`;

const SecondaryButton = styled.button`
  color: white;
  background: transparent;
  border: 1px solid rgba(255, 255, 255, 0.2);
  padding: 1rem 3rem;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  transition: all 0.3s ease;
  border-radius: 0.125rem;
  cursor: pointer;
  display: flex;
  align-items: center;

  &:hover {
    color: #e74c3c;
    border-color: #e74c3c;
    background: transparent;
  }

  .play-icon {
    margin-right: 0.75rem;
    transition: transform 0.3s ease;
  }

  &:hover .play-icon {
    transform: scale(1.1);
  }
`;

const StatsGrid = styled(motion.div)`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 2rem;
  padding-top: 5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.1);

  @media (min-width: 768px) {
    grid-template-columns: repeat(4, 1fr);
  }
`;

const StatItem = styled(motion.div)`
  text-align: center;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const StatNumber = styled.div`
  font-size: clamp(2.25rem, 5vw, 3rem);
  font-weight: 200;
  color: white;
  letter-spacing: -0.03em;

  @media (min-width: 768px) {
    font-size: clamp(2.25rem, 5vw, 3rem);
  }
`;

const StatLabel = styled.div`
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  color: #8a8a8a;
`;

const ScrollIndicator = styled.div`
  position: absolute;
  bottom: 2rem;
  left: 50%;
  transform: translateX(-50%);
`;

const ScrollLine = styled.div`
  width: 1px;
  height: 4rem;
  background: linear-gradient(to bottom, transparent, rgba(255, 255, 255, 0.3), transparent);
`;

const ScrollDot = styled.div`
  width: 0.5rem;
  height: 0.5rem;
  background-color: rgba(255, 255, 255, 0.5);
  border-radius: 50%;
  margin: 0.5rem auto 0;
  animation: ${bounce} 1s infinite;
`;

// Variantes de animación para el Hero
const heroVariants = {
  initial: {
    opacity: 0
  },
  animate: {
    opacity: 1,
    transition: {
      duration: 1,
      staggerChildren: 0.2
    }
  }
};

// Animación del contenedor principal
const contentVariants = {
  initial: {
    opacity: 0,
    y: 30
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: "easeOut",
      staggerChildren: 0.15
    }
  }
};

// Animación de la overline
const overlineVariants = {
  initial: {
    opacity: 0,
    scale: 0.8
  },
  animate: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.6,
      ease: "easeOut"
    }
  }
};

// Animación del título principal
const headlineVariants = {
  initial: {
    opacity: 0,
    y: 50
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: "easeOut",
      staggerChildren: 0.1
    }
  }
};

// Animación del subtítulo
const subheadlineVariants = {
  initial: {
    opacity: 0,
    y: 30
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.7,
      ease: "easeOut"
    }
  }
};

// Animación de los botones CTA
const ctaVariants = {
  initial: {
    opacity: 0,
    y: 40
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: "easeOut",
      staggerChildren: 0.1
    }
  }
};

// Animación de las estadísticas
const statsVariants = {
  initial: {
    opacity: 0,
    y: 50
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: "easeOut",
      staggerChildren: 0.1
    }
  }
};

// Animación individual de cada estadística
const statItemVariants = {
  initial: {
    opacity: 0,
    scale: 0.8
  },
  animate: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.5,
      ease: "easeOut"
    }
  }
};

export function Hero() {
  const stats = [
    { number: "500+", label: "Empresas Confían en Nosotros" },
    { number: "99.9%", label: "Garantía de Disponibilidad" },
    { number: "24/7", label: "Soporte Disponible" },
    { number: "50+", label: "Países Atendidos" }
  ];

  const scrollToSolutions = () => {
    const solutionsSection = document.getElementById('solutions-section');
    if (solutionsSection) {
      solutionsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <HeroSection
      variants={heroVariants}
      initial="initial"
      animate="animate"
    >
      {/* Background geometric elements */}
      <BackgroundElements>
        <PulsingDot1 />
        <PulsingDot2 />
        <PulsingDot3 />
      </BackgroundElements>

      <HeroContent
        variants={contentVariants}
      >
        <ContentContainer>
          {/* Overline */}
          <Overline
            variants={overlineVariants}
          >
            <OverlineDot />
            <OverlineText>
              Soluciones de Inteligencia Artificial
            </OverlineText>
          </Overline>

          {/* Main headline */}
          <HeadlineContainer
            variants={headlineVariants}
          >
            <MainHeadline>
              NUESTRO
              <br />
              <HighlightText>ENFOQUE</HighlightText>
              <br />
              AL TRABAJO
            </MainHeadline>
            
            <SubHeadline
              variants={subheadlineVariants}
            >
              Transformamos empresas a través de automatización inteligente e insights basados en datos, 
              entregando soluciones que escalan con tu ambición y redefinen tu futuro digital.
            </SubHeadline>
          </HeadlineContainer>

          {/* CTA Buttons */}
          <CTAContainer
            variants={ctaVariants}
          >
            <motion.div variants={statItemVariants}>
              <PrimaryButton 
                onClick={scrollToSolutions}
                as={motion.button}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <span>Explorar Soluciones</span>
                <ArrowRight className="arrow-icon" size={16} />
              </PrimaryButton>
            </motion.div>
            
            <motion.div variants={statItemVariants}>
              <SecondaryButton 
                onClick={scrollToSolutions}
                as={motion.button}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Play className="play-icon" size={16} />
                <span>Ver Demo</span>
              </SecondaryButton>
            </motion.div>
          </CTAContainer>

          {/* Stats */}
          <StatsGrid
            variants={statsVariants}
          >
            {stats.map((stat, index) => (
              <StatItem 
                key={index}
                variants={statItemVariants}
              >
                <StatNumber>{stat.number}</StatNumber>
                <StatLabel>{stat.label}</StatLabel>
              </StatItem>
            ))}
          </StatsGrid>
        </ContentContainer>
      </HeroContent>

      {/* Bottom scroll indicator */}
      <ScrollIndicator>
        <ScrollLine />
        <ScrollDot />
      </ScrollIndicator>
    </HeroSection>
  );
}