import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { XCircle, ArrowLeft, RefreshCw, MessageCircle } from "lucide-react";

export function PaymentFailure() {
  const handleRetry = () => {
    // Redirect back to checkout
    window.location.href = '/checkout';
  };

  const handleSupport = () => {
    // Open support chat or redirect to support page
    window.open('mailto:support@itros.ai?subject=Payment%20Issue', '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-slate-900 to-black flex items-center justify-center px-4">
      <div className="max-w-2xl mx-auto text-center space-y-8">
        {/* Error Animation */}
        <div className="relative">
          <div className="w-32 h-32 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-red-500/30 animate-pulse">
            <XCircle className="w-16 h-16 text-white" />
          </div>
          <div className="absolute inset-0 w-32 h-32 bg-red-500/30 rounded-full blur-xl mx-auto animate-ping"></div>
        </div>

        <div className="space-y-4">
          <h1 className="text-4xl lg:text-5xl font-light text-white">
            Pago{" "}
            <span className="bg-gradient-to-r from-red-400 to-red-500 bg-clip-text text-transparent">
              no procesado
            </span>
          </h1>
          <p className="text-xl text-white/70">
            Hubo un problema al procesar tu pago. 
            No te preocupes, no se realizó ningún cargo a tu cuenta.
          </p>
        </div>

        {/* Error Details */}
        <Card className="border border-red-500/30 shadow-2xl bg-red-500/10 backdrop-blur-xl">
          <CardContent className="p-6 space-y-4">
            <h3 className="text-lg font-medium text-white">Posibles causas:</h3>
            <div className="space-y-2 text-left">
              {[
                'Fondos insuficientes en la cuenta',
                'Datos de la tarjeta incorrectos',
                'Límite de la tarjeta excedido',
                'Problema temporal con el banco'
              ].map((cause, index) => (
                <div key={index} className="flex items-center gap-3 text-white/80">
                  <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                  {cause}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={handleRetry}
            size="lg"
            className="bg-gradient-to-r from-electric-blue to-cyan-400 hover:from-cyan-400 hover:to-electric-blue text-white shadow-2xl shadow-electric-blue/30 hover:shadow-electric-blue/60 transition-all duration-500 hover:scale-105 backdrop-blur-sm border border-white/10"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Intentar nuevamente
          </Button>
          
          <Button 
            onClick={handleSupport}
            variant="outline"
            size="lg"
            className="border-white/30 text-white hover:bg-white/10 backdrop-blur-xl shadow-lg shadow-black/10 hover:shadow-black/20 transition-all duration-500 hover:scale-105 hover:border-white/50"
          >
            <MessageCircle className="w-4 h-4 mr-2" />
            Contactar Soporte
          </Button>
        </div>

        <Button 
          variant="ghost"
          onClick={() => window.location.href = '/'}
          className="text-white/70 hover:text-white hover:bg-white/5 backdrop-blur-sm"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Volver al inicio
        </Button>

        {/* Support Info */}
        <Card className="border border-white/20 shadow-2xl bg-white/5 backdrop-blur-xl">
          <CardContent className="p-6">
            <h3 className="text-lg font-medium text-white mb-3">¿Necesitas ayuda?</h3>
            <p className="text-white/70 mb-4">
              Nuestro equipo de soporte está disponible 24/7 para ayudarte con cualquier problema de pago.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 text-sm">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-electric-blue" />
                <span className="text-white/80">Chat en vivo</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-white/80">Email: support@itros.ai</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-white/80">WhatsApp: +1 (555) 123-4567</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}