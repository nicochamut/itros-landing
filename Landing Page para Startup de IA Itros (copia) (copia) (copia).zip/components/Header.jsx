import React, { useState } from "react";
import styled from "styled-components";
import { motion, AnimatePresence } from "motion/react";
import { Brain, Menu, X } from "lucide-react";

const HeaderContainer = styled(motion.header)`
  position: sticky;
  top: 0;
  z-index: 50;
  background-color: rgba(15, 15, 15, 0.9);
  backdrop-filter: blur(48px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
`;

const HeaderContent = styled.div`
  max-width: 80rem;
  margin: 0 auto;
  padding: 0 1.5rem;

  @media (min-width: 1024px) {
    padding: 0 2rem;
  }
`;

const HeaderInner = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 5rem;
`;

const LogoGroup = styled(motion.div)`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  cursor: pointer;

  &:hover .logo-icon {
    background-color: #e67e22;
  }
`;

const LogoIcon = styled(motion.div)`
  width: 2.5rem;
  height: 2.5rem;
  background-color: #e74c3c;
  border-radius: 0.125rem;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
`;

const LogoText = styled.span`
  font-size: 1.5rem;
  font-weight: 200;
  color: white;
  letter-spacing: -0.025em;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
`;

const DesktopNav = styled(motion.nav)`
  display: none;
  align-items: center;
  gap: 3rem;

  @media (min-width: 1024px) {
    display: flex;
  }
`;

const NavButton = styled.button`
  color: #8a8a8a;
  font-size: 0.75rem;
  font-weight: 600;
  line-height: 1.2;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  transition: all 0.3s ease;
  position: relative;
  background: none;
  border: none;
  cursor: pointer;

  &:hover {
    color: white;
  }

  &::after {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    bottom: -0.25rem;
    height: 1px;
    background-color: #e74c3c;
    transform: scaleX(0);
    transition: transform 0.3s ease;
  }

  &:hover::after {
    transform: scaleX(1);
  }
`;

const DesktopCTA = styled(motion.div)`
  display: none;
  align-items: center;
  gap: 1.5rem;

  @media (min-width: 1024px) {
    display: flex;
  }
`;

const GhostButton = styled.button`
  color: #8a8a8a;
  background: transparent;
  border: none;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  transition: all 0.3s ease;
  cursor: pointer;

  &:hover {
    color: white;
    background: transparent;
  }
`;

const PrimaryButton = styled.button`
  background-color: #e74c3c;
  color: white;
  padding: 0.75rem 2rem;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  transition: all 0.3s ease;
  border: none;
  border-radius: 0.125rem;
  cursor: pointer;

  &:hover {
    background-color: #e67e22;
  }
`;

const MobileMenuButton = styled.button`
  display: block;
  color: white;
  background: transparent;
  border: none;
  padding: 0;
  cursor: pointer;

  &:hover {
    background: transparent;
  }

  @media (min-width: 1024px) {
    display: none;
  }
`;

const MobileMenu = styled(motion.div)`
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  padding: 2rem 0;
  background-color: #0f0f0f;

  @media (min-width: 1024px) {
    display: none;
  }
`;

const MobileNavButton = styled.button`
  display: block;
  color: #8a8a8a;
  background: none;
  border: none;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  transition: all 0.3s ease;
  margin-bottom: 1.5rem;
  cursor: pointer;

  &:hover {
    color: white;
  }
`;

const MobileNavLink = styled.a`
  display: block;
  color: #8a8a8a;
  text-decoration: none;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  transition: all 0.3s ease;

  &:hover {
    color: white;
  }
`;

const MobileCTAContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  padding-top: 1.5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
`;

const MobileGhostButton = styled.button`
  width: 100%;
  justify-content: flex-start;
  display: flex;
  color: #8a8a8a;
  background: transparent;
  border: none;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  cursor: pointer;

  &:hover {
    color: white;
    background: transparent;
  }
`;

const MobilePrimaryButton = styled.button`
  background-color: #e74c3c;
  color: white;
  width: 100%;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  transition: all 0.3s ease;
  border: none;
  border-radius: 0.125rem;
  padding: 0.75rem;
  cursor: pointer;

  &:hover {
    background-color: #e67e22;
  }
`;

// Animación del header
const headerVariants = {
  initial: {
    y: -100,
    opacity: 0
  },
  animate: {
    y: 0,
    opacity: 1,
    transition: {
      duration: 0.6,
      ease: "easeOut",
      staggerChildren: 0.1
    }
  }
};

// Animación del logo
const logoVariants = {
  initial: {
    scale: 0,
    opacity: 0
  },
  animate: {
    scale: 1,
    opacity: 1,
    transition: {
      duration: 0.5,
      ease: "easeOut"
    }
  }
};

// Animación de la navegación
const navVariants = {
  initial: {
    opacity: 0,
    x: 20
  },
  animate: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.5,
      staggerChildren: 0.1
    }
  }
};

// Animación del CTA
const ctaVariants = {
  initial: {
    opacity: 0,
    x: 20
  },
  animate: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.5,
      staggerChildren: 0.1
    }
  }
};

// Animación del menú móvil
const mobileMenuVariants = {
  initial: {
    opacity: 0,
    height: 0
  },
  animate: {
    opacity: 1,
    height: "auto",
    transition: {
      duration: 0.3,
      ease: "easeOut",
      staggerChildren: 0.05
    }
  },
  exit: {
    opacity: 0,
    height: 0,
    transition: {
      duration: 0.2,
      ease: "easeIn"
    }
  }
};

// Animación de elementos del menú móvil
const mobileItemVariants = {
  initial: {
    opacity: 0,
    x: -20
  },
  animate: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.3
    }
  },
  exit: {
    opacity: 0,
    x: -20,
    transition: {
      duration: 0.2
    }
  }
};

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <HeaderContainer
      variants={headerVariants}
      initial="initial"
      animate="animate"
    >
      <HeaderContent>
        <HeaderInner>
          {/* Logo */}
          <LogoGroup
            variants={logoVariants}
          >
            <LogoIcon 
              className="logo-icon"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Brain size={24} color="white" />
            </LogoIcon>
            <LogoText>Itros</LogoText>
          </LogoGroup>
          
          {/* Navigation - Desktop */}
          <DesktopNav
            variants={navVariants}
          >
            <motion.div variants={mobileItemVariants}>
              <NavButton 
                onClick={() => {
                  const section = document.getElementById('solutions-section');
                  if (section) section.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Servicios
              </NavButton>
            </motion.div>
            <motion.div variants={mobileItemVariants}>
              <NavButton 
                onClick={() => {
                  const section = document.getElementById('benefits-section');
                  if (section) section.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Soluciones
              </NavButton>
            </motion.div>
            <motion.div variants={mobileItemVariants}>
              <NavButton 
                onClick={() => {
                  const section = document.getElementById('testimonials-section');
                  if (section) section.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Testimonios
              </NavButton>
            </motion.div>
            <motion.div variants={mobileItemVariants}>
              <NavButton as="a" href="#">
                Nosotros
              </NavButton>
            </motion.div>
          </DesktopNav>
          
          {/* CTA - Desktop */}
          <DesktopCTA
            variants={ctaVariants}
          >
            <motion.div variants={mobileItemVariants}>
              <GhostButton>
                Iniciar Sesión
              </GhostButton>
            </motion.div>
            <motion.div variants={mobileItemVariants}>
              <PrimaryButton 
                onClick={() => {
                  const section = document.getElementById('cta-section');
                  if (section) section.scrollIntoView({ behavior: 'smooth' });
                }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Comenzar
              </PrimaryButton>
            </motion.div>
          </DesktopCTA>
          
          {/* Mobile menu button */}
          <MobileMenuButton
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            as={motion.button}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {mobileMenuOpen ? (
              <X size={24} />
            ) : (
              <Menu size={24} />
            )}
          </MobileMenuButton>
        </HeaderInner>
        
        {/* Mobile Navigation */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <MobileMenu
              variants={mobileMenuVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <motion.div variants={mobileItemVariants}>
                <MobileNavButton 
                  onClick={() => {
                    const section = document.getElementById('solutions-section');
                    if (section) section.scrollIntoView({ behavior: 'smooth' });
                    setMobileMenuOpen(false);
                  }}
                >
                  Servicios
                </MobileNavButton>
              </motion.div>
              <motion.div variants={mobileItemVariants}>
                <MobileNavButton 
                  onClick={() => {
                    const section = document.getElementById('benefits-section');
                    if (section) section.scrollIntoView({ behavior: 'smooth' });
                    setMobileMenuOpen(false);
                  }}
                >
                  Soluciones
                </MobileNavButton>
              </motion.div>
              <motion.div variants={mobileItemVariants}>
                <MobileNavButton 
                  onClick={() => {
                    const section = document.getElementById('testimonials-section');
                    if (section) section.scrollIntoView({ behavior: 'smooth' });
                    setMobileMenuOpen(false);
                  }}
                >
                  Testimonios
                </MobileNavButton>
              </motion.div>
              <motion.div variants={mobileItemVariants}>
                <MobileNavLink href="#">
                  Nosotros
                </MobileNavLink>
              </motion.div>
              <motion.div variants={mobileItemVariants}>
                <MobileCTAContainer>
                  <MobileGhostButton>
                    Iniciar Sesión
                  </MobileGhostButton>
                  <MobilePrimaryButton 
                    onClick={() => {
                      const section = document.getElementById('cta-section');
                      if (section) section.scrollIntoView({ behavior: 'smooth' });
                      setMobileMenuOpen(false);
                    }}
                  >
                    Comenzar
                  </MobilePrimaryButton>
                </MobileCTAContainer>
              </motion.div>
            </MobileMenu>
          )}
        </AnimatePresence>
      </HeaderContent>
    </HeaderContainer>
  );
}