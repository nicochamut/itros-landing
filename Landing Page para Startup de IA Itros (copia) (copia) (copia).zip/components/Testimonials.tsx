import { Card, CardContent } from "./ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "./ui/avatar";
import { Quote, Star } from "lucide-react";

const testimonials = [
  {
    name: "María González",
    role: "CEO, TechCorp",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b192?w=400&h=400&fit=crop&crop=face",
    quote: "Itros transformó completamente nuestra capacidad de análisis de datos. Los insights que obtenemos ahora nos han permitido aumentar nuestros ingresos en un 40% y optimizar procesos que creíamos imposibles de mejorar."
  },
  {
    name: "Carlos Mendoza",
    role: "CTO, InnovateLab",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
    quote: "La implementación fue sorprendentemente sencilla. En menos de una semana teníamos nuestros primeros modelos de IA funcionando perfectamente, y el equipo de soporte nos acompañó en cada paso del proceso."
  },
  {
    name: "Ana Rodríguez",
    role: "Directora de Datos, DataFlow",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
    quote: "El soporte técnico es excepcional. Siempre están disponibles para ayudarnos a optimizar nuestros procesos y resolver cualquier duda. La plataforma ha superado todas nuestras expectativas iniciales."
  }
];

export function Testimonials() {
  return (
    <section id="testimonials-section" className="py-32 px-6 lg:px-8 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1/3 right-0 w-72 h-72 bg-corporate-red/30 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/3 left-0 w-64 h-64 bg-corporate-orange/20 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center space-y-8 mb-24">
          <div className="space-y-6">
            <h6 className="text-overline text-corporate-text-muted">
              Testimonios
            </h6>
            <h2 className="text-white tracking-extra-tight">
              LO QUE DICEN
              <br />
              <span className="text-corporate-red">NUESTROS CLIENTES</span>
            </h2>
          </div>
          <p className="text-body-large text-corporate-text-muted max-w-3xl mx-auto">
            Empresas de todo el mundo confían en Itros para impulsar 
            su transformación digital con inteligencia artificial de vanguardia y resultados comprobados.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card 
              key={index}
              className="border border-white/10 bg-white/5 backdrop-blur-sm hover:bg-white/10 transition-all duration-500 group hover:-translate-y-2 overflow-hidden relative"
            >
              {/* Gradient hover effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-corporate-red/5 via-transparent to-corporate-orange/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              
              <CardContent className="p-8 space-y-6 relative z-10">
                <div className="flex items-center justify-between">
                  <Quote className="w-8 h-8 text-corporate-red/50 group-hover:text-corporate-red group-hover:scale-110 transition-all duration-300" />
                  <div className="flex text-corporate-orange/60 group-hover:text-corporate-orange transition-colors duration-300">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className="w-4 h-4 fill-current" 
                      />
                    ))}
                  </div>
                </div>
                
                <p className="text-body-small text-corporate-text-muted italic leading-relaxed group-hover:text-white/90 transition-colors duration-300">
                  "{testimonial.quote}"
                </p>
                
                <div className="flex items-center gap-4 pt-4 border-t border-white/10 group-hover:border-white/20 transition-colors duration-300">
                  <div className="relative">
                    <Avatar className="w-12 h-12 ring-1 ring-white/20 group-hover:ring-corporate-red/50 transition-all duration-300 group-hover:scale-110">
                      <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                      <AvatarFallback className="bg-white/10 text-white backdrop-blur-sm font-medium">
                        {testimonial.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  <div>
                    <div className="font-medium text-white group-hover:text-corporate-red transition-colors duration-300">{testimonial.name}</div>
                    <div className="text-body-small text-corporate-text-muted group-hover:text-white/90 transition-colors duration-300">{testimonial.role}</div>
                  </div>
                </div>
                
                {/* Bottom accent line */}
                <div className="absolute bottom-0 left-0 w-0 h-px bg-gradient-to-r from-corporate-red to-corporate-orange group-hover:w-full transition-all duration-700"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}