import { useEffect, useState } from 'react';
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { CheckCircle, Download, ArrowRight, Sparkles, Crown } from "lucide-react";

export function PaymentSuccess() {
  const [orderDetails, setOrderDetails] = useState<any>(null);

  useEffect(() => {
    // Get order ID from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const orderId = urlParams.get('external_reference');
    
    if (orderId) {
      // In a real app, fetch order details here
      setOrderDetails({
        orderId,
        plan: 'professional', // This would come from the API
        amount: 99.99
      });
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-slate-900 to-black flex items-center justify-center px-4">
      <div className="max-w-2xl mx-auto text-center space-y-8">
        {/* Success Animation */}
        <div className="relative">
          <div className="w-32 h-32 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-green-500/30 animate-pulse">
            <CheckCircle className="w-16 h-16 text-white" />
          </div>
          <div className="absolute inset-0 w-32 h-32 bg-green-400/30 rounded-full blur-xl mx-auto animate-ping"></div>
        </div>

        <div className="space-y-4">
          <h1 className="text-4xl lg:text-5xl font-light text-white">
            ¡Pago{" "}
            <span className="bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
              exitoso!
            </span>
          </h1>
          <p className="text-xl text-white/70">
            Tu suscripción ha sido activada correctamente. 
            Ya puedes acceder a todas las funcionalidades de Itros IA.
          </p>
        </div>

        {orderDetails && (
          <Card className="border border-white/20 shadow-2xl bg-white/10 backdrop-blur-xl">
            <CardContent className="p-8 space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-white/70">ID de Orden:</span>
                <span className="font-mono text-white text-sm">{orderDetails.orderId}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/70">Plan:</span>
                <div className="flex items-center gap-2">
                  <Crown className="w-4 h-4 text-purple-400" />
                  <span className="text-white capitalize">{orderDetails.plan}</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/70">Monto:</span>
                <span className="text-white font-medium">${orderDetails.amount} USD</span>
              </div>
              <div className="border-t border-white/20 pt-4">
                <div className="text-sm text-white/60">
                  Recibirás un email de confirmación con todos los detalles de tu suscripción.
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            size="lg"
            className="bg-gradient-to-r from-electric-blue to-cyan-400 hover:from-cyan-400 hover:to-electric-blue text-white shadow-2xl shadow-electric-blue/30 hover:shadow-electric-blue/60 transition-all duration-500 hover:scale-105 backdrop-blur-sm border border-white/10"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Acceder al Dashboard
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
          
          <Button 
            variant="outline"
            size="lg"
            className="border-white/30 text-white hover:bg-white/10 backdrop-blur-xl shadow-lg shadow-black/10 hover:shadow-black/20 transition-all duration-500 hover:scale-105 hover:border-white/50"
          >
            <Download className="w-4 h-4 mr-2" />
            Descargar Factura
          </Button>
        </div>

        {/* Next Steps */}
        <Card className="border border-white/20 shadow-2xl bg-white/5 backdrop-blur-xl">
          <CardContent className="p-6">
            <h3 className="text-lg font-medium text-white mb-4">Próximos pasos:</h3>
            <div className="space-y-3 text-left">
              {[
                'Configura tu perfil y preferencias',
                'Explora las herramientas de IA disponibles',
                'Conecta tus fuentes de datos',
                'Programa una demo personalizada'
              ].map((step, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-6 h-6 bg-electric-blue/30 rounded-full flex items-center justify-center text-xs text-white">
                    {index + 1}
                  </div>
                  <span className="text-white/80">{step}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}