import { useEffect, useState } from 'react';
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Clock, RefreshCw, CheckCircle, AlertCircle } from "lucide-react";
import { projectId, publicAnonKey } from '../utils/supabase/info';

export function PaymentPending() {
  const [orderStatus, setOrderStatus] = useState<'pending' | 'approved' | 'rejected'>('pending');
  const [isChecking, setIsChecking] = useState(false);
  const [orderId, setOrderId] = useState<string>('');

  useEffect(() => {
    // Get order ID from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const externalReference = urlParams.get('external_reference');
    if (externalReference) {
      setOrderId(externalReference);
    }

    // Auto-check status every 10 seconds
    const interval = setInterval(checkPaymentStatus, 10000);
    return () => clearInterval(interval);
  }, [orderId]);

  const checkPaymentStatus = async () => {
    if (!orderId || isChecking) return;

    setIsChecking(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-f21ceeec/payment-status/${orderId}`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        setOrderStatus(data.status);
        
        // Redirect based on status
        if (data.status === 'approved') {
          setTimeout(() => {
            window.location.href = `/payment-success?external_reference=${orderId}`;
          }, 2000);
        } else if (data.status === 'rejected') {
          setTimeout(() => {
            window.location.href = '/payment-failure';
          }, 2000);
        }
      }
    } catch (error) {
      console.error('Error checking payment status:', error);
    } finally {
      setIsChecking(false);
    }
  };

  const getStatusInfo = () => {
    switch (orderStatus) {
      case 'approved':
        return {
          icon: CheckCircle,
          color: 'from-green-400 to-emerald-500',
          bgColor: 'bg-green-500/20',
          borderColor: 'border-green-500/30',
          textColor: 'text-green-300',
          title: '¡Pago aprobado!',
          message: 'Tu pago ha sido procesado exitosamente. Redirigiendo...'
        };
      case 'rejected':
        return {
          icon: AlertCircle,
          color: 'from-red-500 to-red-600',
          bgColor: 'bg-red-500/20',
          borderColor: 'border-red-500/30',
          textColor: 'text-red-300',
          title: 'Pago rechazado',
          message: 'Tu pago no pudo ser procesado. Redirigiendo...'
        };
      default:
        return {
          icon: Clock,
          color: 'from-yellow-400 to-orange-500',
          bgColor: 'bg-yellow-500/20',
          borderColor: 'border-yellow-500/30',
          textColor: 'text-yellow-300',
          title: 'Pago en proceso',
          message: 'Estamos procesando tu pago. Esto puede tomar unos minutos.'
        };
    }
  };

  const statusInfo = getStatusInfo();
  const StatusIcon = statusInfo.icon;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-slate-900 to-black flex items-center justify-center px-4">
      <div className="max-w-2xl mx-auto text-center space-y-8">
        {/* Status Animation */}
        <div className="relative">
          <div className={`w-32 h-32 bg-gradient-to-br ${statusInfo.color} rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-yellow-500/30 ${orderStatus === 'pending' ? 'animate-pulse' : ''}`}>
            <StatusIcon className="w-16 h-16 text-white" />
          </div>
          {orderStatus === 'pending' && (
            <div className="absolute inset-0 w-32 h-32 bg-yellow-400/30 rounded-full blur-xl mx-auto animate-ping"></div>
          )}
        </div>

        <div className="space-y-4">
          <h1 className="text-4xl lg:text-5xl font-light text-white">
            {statusInfo.title}
          </h1>
          <p className="text-xl text-white/70">
            {statusInfo.message}
          </p>
        </div>

        {/* Status Details */}
        <Card className={`border ${statusInfo.borderColor} shadow-2xl ${statusInfo.bgColor} backdrop-blur-xl`}>
          <CardContent className="p-6 space-y-4">
            {orderId && (
              <div className="flex items-center justify-between">
                <span className="text-white/70">ID de Orden:</span>
                <span className="font-mono text-white text-sm">{orderId}</span>
              </div>
            )}
            
            {orderStatus === 'pending' && (
              <div className="space-y-4">
                <div className={`p-4 ${statusInfo.bgColor} rounded-lg ${statusInfo.borderColor} border backdrop-blur-sm`}>
                  <div className={`text-sm ${statusInfo.textColor} mb-2`}>
                    ¿Qué está sucediendo?
                  </div>
                  <div className="space-y-2 text-left text-white/80 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                      Verificando con la entidad bancaria
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-white/40 rounded-full"></div>
                      Procesando la transacción
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-white/40 rounded-full"></div>
                      Activando tu suscripción
                    </div>
                  </div>
                </div>

                <div className="text-xs text-white/60">
                  Actualizamos el estado automáticamente cada 10 segundos
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {orderStatus === 'pending' && (
          <Button 
            onClick={checkPaymentStatus}
            disabled={isChecking}
            size="lg"
            className="bg-gradient-to-r from-electric-blue to-cyan-400 hover:from-cyan-400 hover:to-electric-blue text-white shadow-2xl shadow-electric-blue/30 hover:shadow-electric-blue/60 transition-all duration-500 hover:scale-105 backdrop-blur-sm border border-white/10"
          >
            {isChecking ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Verificando...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                Verificar estado
              </>
            )}
          </Button>
        )}

        {/* Help Section */}
        <Card className="border border-white/20 shadow-2xl bg-white/5 backdrop-blur-xl">
          <CardContent className="p-6">
            <h3 className="text-lg font-medium text-white mb-3">Información importante:</h3>
            <div className="space-y-2 text-left text-white/70 text-sm">
              <p>• Los pagos pueden tardar entre 1 y 10 minutos en procesarse</p>
              <p>• Recibirás un email de confirmación una vez aprobado el pago</p>
              <p>• Si el pago es rechazado, no se realizará ningún cargo</p>
              <p>• Para pagos en efectivo, puede tomar hasta 24 horas</p>
            </div>
          </CardContent>
        </Card>

        <Button 
          variant="ghost"
          onClick={() => window.location.href = '/'}
          className="text-white/70 hover:text-white hover:bg-white/5 backdrop-blur-sm"
        >
          Volver al inicio
        </Button>
      </div>
    </div>
  );
}